
function alertMessage(element){
    alert("Your cart is empty")
}


function closeOne(element) {
    var div = document.getElementById("acceptAllCookies").innerHTML = acceptAllCookies;
    div.style.display = 'none'
}